var indexSectionsWithContent =
{
  0: "acdeglrsw",
  1: "d",
  2: "d",
  3: "acdeglrsw",
  4: "a",
  5: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

